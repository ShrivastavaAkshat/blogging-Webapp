
let firebaseConfig = {
    apiKey: "AIzaSyDjXNWo9EmWO2F245EStOnjxZHpyYcXVC8",
  authDomain: "blog-3b86b.firebaseapp.com",
  projectId: "blog-3b86b",
  storageBucket: "blog-3b86b.appspot.com",
  messagingSenderId: "207311284001",
  appId: "1:207311284001:web:7ff75cc4afa21eded70060"
};

firebase.initializeApp(firebaseConfig);

let db = firebase.firestore();